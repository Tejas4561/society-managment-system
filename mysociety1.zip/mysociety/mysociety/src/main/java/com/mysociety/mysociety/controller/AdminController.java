package com.mysociety.mysociety.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.mysociety.mysociety.entity.Admin;
import com.mysociety.mysociety.entity.Residents;
import com.mysociety.mysociety.services.AdminServices;
import com.mysociety.mysociety.services.ResidentServices;

@Controller
public class AdminController {
	@Autowired
	private AdminServices adminservices;
	private Admin admin;
	@Autowired
	private ResidentServices residentservices;
	private Residents residents;

	public AdminController(AdminServices adminservices, ResidentServices residentservices) {
		this.adminservices = adminservices;
		this.residentservices = residentservices;
	}

	@GetMapping("home")
	public String getHome() {
		return "home";
	}

	@GetMapping("/signup")
	public String getSignup(Model model) {
		model.addAttribute("admin", new Admin());
		return "signup";
	}

	@PostMapping("/signup")
	public String submitSignupForm(@ModelAttribute Admin admin) {
		adminservices.saveAdmin(admin);
		System.out.println(admin);
		return "adminDash";
	}

	@GetMapping("/login")
	public String showLoginForm(Model model) {
		model.addAttribute("adminLogin", new Admin());
		return "login";
	}

	@PostMapping("/login")
	public String loginAdmin(@ModelAttribute("adminLogin") Admin admin, Model model) {
		List<Admin> loggedInAdmin = adminservices.loginAdmin(admin.getEmail(), admin.getPassword());
//		if (loggedInAdmin != null) { 
//			model.addAttribute("admin", loggedInAdmin); 
//			return "adminDash"; 
//			} else 
//				
//			
//			{ return "login"; 
//			
		if (!loggedInAdmin.isEmpty()) {
			model.addAttribute("admin", loggedInAdmin.get(0));
			return "adminDash";
		} else {
			return "login";
		}
	}

	@GetMapping("/usersignup")
	public String getSignup1(Model model) {
		model.addAttribute("residents", new Residents());
		return "usersignup"; 
		} 
	@PostMapping("/resident/usersignu") 
		public String submitSignupForm1(@ModelAttribute Residents residents, Model model) {
			residentservices.saveResidents(residents); 
			return "residentDash"; 
			}
	

	@PostMapping("/login1")
	public String loginResidents(@ModelAttribute("residentLogin") Residents residents, Model model) {
		List<Residents> loggedInResidents = residentservices.loginResidents(residents.getEmail(),residents.getPassword());
		if (!loggedInResidents.isEmpty()) {
			model.addAttribute("residents",loggedInResidents.get(0));
			 return "residentDash"; }
			else {
				return "login1"; 
				}
		}	
}
