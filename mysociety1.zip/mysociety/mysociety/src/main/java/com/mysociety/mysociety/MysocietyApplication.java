package com.mysociety.mysociety;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysocietyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysocietyApplication.class, args);
	}

}
