package com.mysociety.mysociety.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysociety.mysociety.entity.Admin;
import com.mysociety.mysociety.repository.AdminRepo;

@Service
public class AdminServices {
	@Autowired
	private AdminRepo adminrepo;

	public AdminServices(AdminRepo adminrepo) {
		this.adminrepo = adminrepo;
	}

	@Transactional
	public Admin saveAdmin(Admin admin) {
		return adminrepo.save(admin);
	}

	@Transactional
	public List<Admin> loginAdmin(String email, String password) {
		return adminrepo.findByEmailAndPassword(email, password);
	}

}
