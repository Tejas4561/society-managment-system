package com.mysociety.mysociety.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import com.mysociety.mysociety.entity.Admin;
import com.mysociety.mysociety.entity.Residents;
import com.mysociety.mysociety.repository.ResidentRepo;

@Service
public class ResidentServices {
	@Autowired
	private ResidentRepo residentRepo;
	
	public ResidentServices(ResidentRepo residentRepo) {
		this.residentRepo=residentRepo;
	}
	public Residents saveResidents(Residents resident) {
		return residentRepo.save(resident);
		
	}
	@Transactional
	public List<Residents>loginResidents(String email, String password) {
		return residentRepo.findByEmailAndPassword(email, password);
	}
	
}
