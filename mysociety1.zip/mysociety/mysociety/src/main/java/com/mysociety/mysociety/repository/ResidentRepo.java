package com.mysociety.mysociety.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import com.mysociety.mysociety.entity.Admin;
import com.mysociety.mysociety.entity.Residents;

@Repository
public interface ResidentRepo extends JpaRepository<Residents, Integer> {
	List<Residents> findByEmailAndPassword(String email, String password);

}
